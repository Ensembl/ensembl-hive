
package Bio::EnsEMBL::Hive::RunnableDB::LongMult::AddArray;

use strict;
use List::Util ('max');

# Hive Runnable code here
# ...
# ...


# the math behind long addition:

sub _add_array {
    my ($b_array) = @_;

    return 0 unless(scalar(@$b_array));

    my @accu  = ();

    foreach my $b_element (@$b_array) {
        my @b_digits = reverse split(//, $b_element);
        foreach my $position (0..scalar(@b_digits)-1) {
            $accu[$position] += $b_digits[$position];
        }
    }

    foreach my $a_index (0..(@accu-1)) {
        my $a_digit       = $accu[$a_index];
        my $carry         = int($a_digit/10);
        $accu[$a_index]   = $a_digit % 10;
        $accu[$a_index+1] += $carry;
    }

        # get rid of the leading zero
    unless($accu[@accu-1]) {
        pop @accu;
    }

    return join('', reverse @accu);
}

1;

